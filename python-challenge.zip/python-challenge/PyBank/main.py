import os
import csv

total = 0
net_change_list = []
month_change_list = []
greatest_increase = ["", 0]
greatest_decrease = ["", 99999999999999]

budget_data = os.path.join('..', 'PyBank', 'Resources', 'budget_data.csv')
with open(budget_data, "r") as f:
    reader = csv.reader(f, delimiter=",")
    header_line = next(f)
    data = list(reader)
    row_count = len(data)
    print(f' The correct answer is {row_count}')
    header_line = next(reader)
    total = total + int(first_row[1])
    previous_net = int(first_row[1])
    for row in reader:
        total = total + int(row[1])
        net_change = int(row[1])-previous_net
        net_change_list = net_change_list + [net_change]
        month_change_list = month_change_list + [row[0]]
    if net_change > greatest_increase[1]:
        greatest_increase[0] = row[0]
        greatest_increase[1] = net_change
    if net_change > greatest_decrease[1]:
        greatest_decrease[0] = row[0]
        greatest_decrease[1] = net_change
