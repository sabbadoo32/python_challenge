import os
import csv

election_data = os.path.join('..', 'PyPoll', 'Resources', 'election_data.csv')
with open(file,'r') as f:
    reader = csv.reader(f)
    header = next(reader)
    result = []
    for row in reader:
        for col_index, colname in enumerate(header)[2:]:
            value = row[col_index]
            result.append(do_something_with(value, colname))